
# PW Books & Premium Notes Website

This is a simple promo website for Telegram channels offering free and premium PW (Physics Wallah) content.

## 🔗 Telegram Channels

- **PW Books:** https://t.me/+kKX_iJYY2DIwMDM1
- **PW Premium Notes:** https://t.me/+d1QghpALIEJlMTg1
- **PW Official Updates:** https://t.me/+NrFHp6jhQRBhOTNl

## 🌐 Live Website

Deploy this site with GitHub Pages or Netlify.

## 🖼️ Preview

![Website Preview](preview.png)
